# from facedetector import *
# # import cv2
# # image = cv2.imread("a1.png")
# # print(image.shape)
# # cv2.imshow("name",image)
# # x = face_predict(image)
# # assert match(x,x) == 0
# # print(x)
import pickle as pk 
fin = open("embeddings",'rb')
predictions = pk.load(fin)
fin.close()
for x in predictions:
    print(x ,"=>",predictions[x])