from flask import Flask, jsonify,request
from PIL import Image
import numpy as np
import pickle as pk
from scipy.spatial.distance import cosine
from keras_vggface.vggface import VGGFace
import tensorflow as tf
from facedetector import *


app = Flask(__name__)
global model
# global graph
# tf_config = some_custom_config
# sess = tf.Session(config=tf_config)
# graph = tf.get_default_graph()
# set_session(sess)
# model = VGGFace(model='resnet50', include_top=False, input_shape=(224, 224, 3), pooling='avg',weights='vggface')


@app.route('/',methods=['GET'])
def hello_world():
    return jsonify({'task': 'hello from python'})

@app.route("/image_query", methods=["POST"])
def home():
    print("Entered the api endpoint")
    img = Image.open(request.files['file'])
    image = np.array(img)
    print("Image Extracted")
    locs = search(image)
    return jsonify({'locations': locs[:20]})

def face_predict(image):
    print("Extracting Face")
    image = face_identify(image)
    pred = None
    # global graph
    # with graph.as_default():
    model = VGGFace(model='resnet50', include_top=False, input_shape=(224, 224, 3), pooling='avg',weights='vggface')
    pred= model.predict(np.array([image]))
    print("prediction of input made")
    return pred 

@app.route("/test",methods=["GET"])
def test():
    import cv2
    image = cv2.imread("a1.png")
    print(image.shape)
    #cv2.imshow("name",image)
    # global graph
    # with graph.as_default():
    #model = VGGFace(model='resnet50', include_top=False, input_shape=(224, 224, 3), pooling='avg',weights='vggface')
    locs = search(image)
    assert len(locs) > 0
    #assert match(x,x) == 0
    #print(x)
    return jsonify({'locations': locs[:20]})

def match(known_embedding, candidate_embedding, thresh=0.5):
  return cosine(known_embedding, candidate_embedding)


def search(image,thresh = 0.4):
    #search in database and return a set of image
    locs = []
    print("finding matching images")
    pred = face_predict(image)
    fin = open("embeddings",'rb')
    predictions = pk.load(fin)
    fin.close()
    print("Embeddings loaded")
    for key,value in predictions.items():
        score  = match(value,pred)
        if(score < 0.4) : locs.append(key)
    return locs    

if __name__ == '__main__':
   app.run(host='0.0.0.0',port=5000,debug=True)
