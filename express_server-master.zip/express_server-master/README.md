### Simple Api server using Express :
* build it using npm install and run using npm start 
